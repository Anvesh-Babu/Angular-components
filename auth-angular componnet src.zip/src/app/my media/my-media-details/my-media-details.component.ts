import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-media-details',
  templateUrl: './my-media-details.component.html',
  styleUrls: ['./my-media-details.component.css']
})
export class MyMediaDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
