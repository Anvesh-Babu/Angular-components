import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { registerLocaleData } from '@angular/common';
import { FormBuilder, FormGroup , FormControl} from '@angular/forms';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  regname : string;
  regmail : string;
  regpass : string;
  regrpass : string;
  errtext : string='';
  myFormGroup : FormGroup;
  constructor(public auth:AuthenticationService, formBuilder: FormBuilder) {   
    this.myFormGroup=formBuilder.group({
    "username" : new FormControl(""),
    "email" : new FormControl(""),
    "password1" : new FormControl(""),
    "password2" : new FormControl(""),
   
  });
  
  }
  register(){
    this.regname = this.myFormGroup.controls['username'].value;
    this.regmail = this.myFormGroup.controls['email'].value;
    this.regpass = this.myFormGroup.controls['password1'].value;
    this.regrpass = this.myFormGroup.controls['password2'].value;
  if (this.regpass === this.regrpass){
        console.log(this.regname+"\n"+this.regmail+"\n"+this.regpass+"\n"+this.regrpass+"\n");
     }
     else{
       this.errtext = "Password not matched";
     }

      
  }
  ngOnInit() {
  }

}
