import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blocked-users',
  templateUrl: './blocked-users.component.html',
  styleUrls: ['./blocked-users.component.css']
})
export class BlockedUsersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
